from flask import Flask, render_template, request, redirect

app = Flask(__name__)


@app.route("/")
def index():
    return render_template('index.html')

@app.route("/we")
def authors():
    return render_template('authors.html')

if __name__ == '__main__':

    app.run(debug=True)
